/** LAB5_FERENCZ446.h
 *	
 *	A re-useable library of input validation functions.
 *	   
 *	@author		Thom MacDonald
 *	@version	2014.01
 *	@since		3 Jan 2014
 *	@see 		Bronson, G. (2012).  Chapter 6 Modularity Using Functions. 
 *					In A First Book of C++ (4th ed.). 
 *					Boston, MA: Course Technology.
*/


#include <sstream>
#include <iostream>
#include <string>

using namespace std;

namespace doubleValidation
{
	string objectName(stringValue) 
	string objectName = value
	bool isValidDouble(string valueToCheck);



	bool isValidDouble(string valueToCheck)
	{
	Try
		Double.Parse(valueToCheck)		
	
	}


	
}


