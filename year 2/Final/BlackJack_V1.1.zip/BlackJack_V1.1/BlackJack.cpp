/** BlackJack.cpp
 *	
 *  The final Black Jack project
 *
 *	@author		Julien Ouimet, Allan Ferencz, Alex Plant
 *	@date		Nov 2014
 *
 *
*/

#include <iostream>		
#include <stdexcept>
#include <ctime>
#include <cstdlib>
#include <vector>
#include <iomanip>
#include <math.h>

#include "StandardPlayingCard.h"
#include "TheDeck.h"
#include <windows.h>

//title display prototypr
void Title();


int main()
{
	int amountOfDecks;
	//size of the deck
	int size = 52;
	//User Input
	char choice;
	//Play Game Variable
	bool playGame = false;
	
	int decks;		 
	while(playGame == false){
		Title();	
		cout << "\n\n\nWelcome to Black Jack!\n" << endl
			 << "\'1\' Play Game" << endl
			 << "\'2\' Change deck Size" << endl;	
		choice = cin.get();
		switch(choice){
			case '1':
				amountOfDecks = 1;
				playGame = true;
			break;
			
			case '2': 
				system("cls");
				Title();
				cout << "\n\nEnter in the amount of decks you would like to use" << endl
					 << "Option for deck size is 1,2,4,6 and 8" << endl;
				cin >> amountOfDecks;
				if (amountOfDecks == 1 ||amountOfDecks == 2 || amountOfDecks == 4 || amountOfDecks == 6 || amountOfDecks == 8){
					decks = amountOfDecks;	
				}
				else{
					system("cls");
					Title();
					cout << "\n\nYou must pick one of the options" << endl;
					system("pause");
				}
			break;
			
		}
		system("cls");
	}
	
	//Create the deck of cards to pull from
	StandardDeck cards(size * decks);
	// We realised that the cards are not actually random with multiple decks but we couldn't get this logic working so we commented it out
//	StandardDeck temp(size);
//	int deckPointer = 52;
//	int count = 1;
//	while(count < decks){
//		temp.Shuffle();
//		deckPointer = 52 * count;
//		for(int i = deckPointer - 52; i = deckPointer; i++){
//			cards[i]=temp[i];}	
//	}
	
	const int DEALER_TARGET_SCORE = 17;
	
	HANDLE  hConsole;
	hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	int dealerColour = 2;
	int playerColour = 15;
	int optionsColour = 6;
	int errorColour = 79;
	int goodColour = 47;
	int pushColour = 159;
	SetConsoleTextAttribute(hConsole, playerColour);
	
	//Exit the game or not
	bool game = true;
	
	// Seed the random number generator
	srand(time(NULL));
	
	//chips in hand
	int chipsInHand = 10;


	system("cls");
			
	//Shuffle the deck of cards
	cards.Shuffle();

//New game			
do 
{			
				
		//The quit variable
		bool needInput = true;
		//Holds the total worth of hand
		int addedCards = 0;
		//Holds the size of the hand
		int handSize = 3;
		//Holds current card
		int currentCard = 2;
		//An array holding cards in hand	
		StandardPlayingCard * hand;
		hand = new (nothrow) StandardPlayingCard[10];
		//An array holding worth of cards in hand
		int handCards[10];
		//The dealers cards worth
		int dealerCards[10];
		//Dealer cards
		StandardPlayingCard * dealerHand;
		dealerHand = new (nothrow) StandardPlayingCard[10];
		//Dealer total
		int dealerTotal = 0;
		//dealr amount of cards
		int dealerCurrentCard = 2;
		//chips bid
		int chipsBid = 0;
		//number of turns played
		int countTurns = 1;
		//Double down check(for when the user is trying to double down and they don't have enough chips too)
		int doubleCheck = 0;
				
		//exit when bust
		bool gameCheck = false;
	
		//give player two first cards and get worth of both
		hand[1] = cards.DrawNextCard();
		hand[2] = cards.DrawNextCard();	
		handCards[1] = hand[1].getWorth();
		handCards[2] = hand[2].getWorth();
		
		//the dealers first card
		dealerHand[1] = cards.DrawNextCard();
		dealerCards[1] = dealerHand[1].getWorth();
	
	Title();
	
	cout << "\n\n\nYou have " << chipsInHand << " chips. Please place a bid: ";
	while (chipsBid < 1 || chipsBid > chipsInHand)
	{
		cin >> chipsBid;
		
		if (cin.fail())
		{
			cout <<"\nYour bet must be numeric." << endl;
			fflush(stdin);
			cin.clear();
			chipsBid = 0;			
		}
		else if (chipsBid <1 || chipsBid > chipsInHand)
		{
			cout << "\nYou must bet 1 to " << chipsInHand << " chips." << endl;
		}	
		
  	}
  	
  	chipsInHand -= chipsBid;	
	 
	cout << "\n\nThe dealer will now deal you 2 cards.\n" << endl;
	system("pause");
	system("cls");
	
	//In game
	do
	{	
	
	if(cards.CardsInDeck() < 52)
	{
		//remake the deck	
		cards.Initialize(52);
		//Shuffle the deck of cards
		cards.Shuffle();
	}
	
	// add first two cards together	
	addedCards = handCards[1]+handCards[2];	
	
	Title();
	
	cout << "CHIPS: " << chipsInHand << endl;
	cout << "BET: " << chipsBid << endl;	
	cout << "\nYour " << currentCard << " cards are: \n\n     The " << hand[1] << endl << "     The " << hand[2];
	
	//display each new card and add to player total
	if (currentCard > 2)
	{
		for (int count = 3; count < currentCard + 1; count++)
		{
			cout << "\n     The " << hand[count]; 
			addedCards = addedCards + handCards[count];
		}
	}
		
	cout << "\n\n     You have " << addedCards << endl; 
	
		//check if bust
		if (addedCards > 21)
		{
			SetConsoleTextAttribute(hConsole, errorColour);
			cout <<"\n\n     You bust, you lose " << chipsBid << " chips. Press any key to continue.\n" << endl;
			SetConsoleTextAttribute(hConsole, playerColour);
			system("pause");
			//delete old arrays to be re-created on new game
			delete [] hand;
			delete [] dealerHand;
			//exits current round
			gameCheck = true;
			needInput = false;
			//clear screen
			system("cls");	
		}
			
	//skip this if game is over due to player bust
	if (gameCheck == false)
	{
		SetConsoleTextAttribute(hConsole, dealerColour);
		cout << "\n\nThe dealer shows a " << dealerHand[1] << endl;
		SetConsoleTextAttribute(hConsole, playerColour); 
		
		//display menu
		SetConsoleTextAttribute(hConsole, optionsColour);
		cout << "\nYour Options " << endl
			 << "=============" << endl << endl
			 << "\'1\' Hit Me!" << endl
			 << "\'2\' I'll Stay" << endl;
		if (countTurns == 1 && chipsBid <= chipsInHand){
		 	cout << "\'3\' Double Down" << endl;
		}
		if(countTurns == 1 ){
		 	cout << "\'4\' Surrender" << endl;			
		}		
		cout << "\'Q\' to Quit" << endl << endl
			 << ": ";
		SetConsoleTextAttribute(hConsole, playerColour);
		
		//get user input		 
		fflush(stdin);
		choice = cin.get();
		choice = toupper(choice);
		system("cls");
		
		//different user choices
		switch(choice)
		{
			case '1': // HIT-HIT-HIT-HIT-HIT-HIT-HIT-HIT-HIT-HIT-HIT-HIT-HIT-HIT-HIT-HIT-HIT-HIT-HIT
				// player draws a random card
				currentCard++;
				hand[currentCard] = cards.DrawNextCard();
				//get the worth of the card
				handCards[currentCard] = hand[currentCard].getWorth();
				Title();
				cout << "\n\n\nYou were dealt the " << hand[currentCard] << endl;
				system("pause");
				system("cls");	
				countTurns++;				
				break;
			case '2': // STAY-STAY-STAY-STAY-STAY-STAY-STAY-STAY-STAY-STAY-STAY-STAY-STAY-STAY-STAY
				//dealer draws a random card
				dealerHand[2] = cards.DrawNextCard();
				//get worth of the card				
				dealerCards[2] = dealerHand[2].getWorth();
				//calculate total of the dealers current cards
				dealerTotal = dealerCards[1]+dealerCards[2];
				//if dealer is losing and has not busted draw cards until one condition is met
				while (dealerTotal < DEALER_TARGET_SCORE)
				{
					dealerCurrentCard++;
					dealerHand[dealerCurrentCard] = cards.DrawNextCard();
					dealerCards[dealerCurrentCard] = dealerHand[dealerCurrentCard].getWorth();
					//the total
					dealerTotal = dealerTotal + dealerCards[dealerCurrentCard];
				}
				
				//Check for game winner or tie(push)
				Title();
				SetConsoleTextAttribute(hConsole, dealerColour);
				cout << "\n\n\nThe dealer has " << dealerTotal << "\n\n\n";
			    SetConsoleTextAttribute(hConsole, goodColour);
				if(dealerTotal < addedCards)
				{
					cout << "    You win this hand. You win " << chipsBid * 2 << " chips\n" << endl;
					chipsInHand += chipsBid * 2;
				}
				else if (dealerTotal > 21)
				{
					cout << "    Dealer Bust! You win this hand. You win " << chipsBid * 2 << " chips\n" << endl;
					chipsInHand += chipsBid * 2;
				}
				else if (dealerTotal == addedCards)
				{
					SetConsoleTextAttribute(hConsole, pushColour);
					cout << "    This hand is a push. You win " << chipsBid << " chip(s)\n" << endl;
					chipsInHand += chipsBid;
					SetConsoleTextAttribute(hConsole, playerColour);
				}
				else
				{
					SetConsoleTextAttribute(hConsole, errorColour);
					cout << "    Dealer wins this hand. You lose " << chipsBid << " chip(s)\n" << endl;
				}
				
				SetConsoleTextAttribute(hConsole, playerColour);
				//delete arrays to be re-created on new game
				delete [] hand;
				delete [] dealerHand;
			
				system("pause");
				//new game
				needInput = false;
			
				system("cls");
				break;
			case '3':
				if (countTurns == 1){
					if (chipsBid <= chipsInHand) {
						chipsInHand -= chipsBid;
						chipsBid += chipsBid;
						currentCard++;
						hand[currentCard] = cards.DrawNextCard();
						//get the worth of the card
						handCards[currentCard] = hand[currentCard].getWorth();
						Title();
						cout << "\n\n\nYou were dealt the " << hand[currentCard] << endl;
						system("pause");
						system("cls");												
						countTurns++;
					}
				}
				break;
			case '4':
				if (countTurns == 1){ 
				chipsInHand += floor(chipsBid/2);
				Title();
				cout << "\n\nYou surrendered this hand" << endl
					 << "You get returned " << floor(chipsBid/2) << " chip(s)" << endl 
					 << endl;
					 				
				delete [] hand;
				delete [] dealerHand;
				system("pause");
				needInput = false;
				system("cls");	
				}
				
				break;
			case 'Q':
				needInput = false;
				game = false;
				break;
			default:
				SetConsoleTextAttribute(hConsole, errorColour);
				cout << "\nUnrecognized choice. Please try again.";
				SetConsoleTextAttribute(hConsole, playerColour);
		}
		
	}
	}while (needInput);
	
	if (chipsInHand < 1)
	{
		system("cls");
		Title();
		SetConsoleTextAttribute(hConsole, errorColour);
		cout << "\n\n\n    You are out of chips. You lose. Press any key to play again.\n" << endl;	
		SetConsoleTextAttribute(hConsole, playerColour);
		system("pause");
		//remake the deck	
		cards.Initialize(52);
		//Shuffle the deck of cards
		cards.Shuffle();
		chipsInHand = 10;
		system("cls");		
	}
}while (game);
			
	cout <<"Thank you for playing!" << endl;
	return 0;	
};


// Display title
void Title()
{
	cout << endl
		 << setw(50) << "-----------------\n"
		 << setw(59) << "\x03 \x04 \x05 \x06 |  BLACK JACK   | \x03 \x04 \x05 \x06 \n" 
		 << setw(50) << "-----------------\n";
}

